#!/bin/bash
cd "$(dirname "$0")"
chmod +x ./DuckyNet.Server
./DuckyNet.Server