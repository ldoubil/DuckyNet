﻿# DuckyNet Linux Release

## Server

Start: cd Server && chmod +x start_server.sh && ./start_server.sh

Port: 9050

## Client (Unity Mod)

Copy Client/*.dll to game Mods folder

Build: 2025-11-05 19:30:38

